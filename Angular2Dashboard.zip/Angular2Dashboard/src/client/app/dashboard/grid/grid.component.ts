import {Component} from '@angular/core';
@Component({
	moduleId: module.id,
    selector: 'grid-cmp',
    templateUrl: './grid.component.html'
})

export class GridComponent {}
