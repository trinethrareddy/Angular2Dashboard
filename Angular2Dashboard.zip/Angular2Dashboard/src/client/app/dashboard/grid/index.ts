/**
 * This barrel file provides the export for the lazy loaded HomeComponent.
 */
export * from './grid.component';
export * from './grid.routes';

