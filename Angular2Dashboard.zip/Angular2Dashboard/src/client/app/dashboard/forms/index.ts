/**
 * This barrel file provides the export for the lazy loaded FormsComponent.
 */
export * from './forms.component';
export * from './forms.routes';
