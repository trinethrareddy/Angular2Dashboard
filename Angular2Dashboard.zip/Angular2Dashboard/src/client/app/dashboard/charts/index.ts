/**
 * This barrel file provides the export for the lazy loaded ChartComponent.
 */
export * from './chart.component';
export * from './chart.route';
