/**
*	This barrel file provides the export for the lazy loaded BSComponent.
*/
export * from './bsComponent.component';
export * from './bsComponent.routes';
