import { Route } from '@angular/router';

import { BSComponentComponent } from './index';

export const BSComponentRoutes: Route[] = [
	{
		path: 'components',
		component: BSComponentComponent
	}
];
